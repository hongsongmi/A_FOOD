from django.contrib import admin
from .models import myText

admin.site.register(myText)
