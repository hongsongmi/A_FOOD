from django.shortcuts import render
from .models import myText

# Create your views here.
def home_list(request):
    texts = myText.objects.filter()

    eat_list = myText.objects.filter(category='eat')
    date_list = myText.objects.filter(category='date')
    activity_list = myText.objects.filter(category='activity')
    see_list = myText.objects.filter(category='see')


    return render(request, 'thema/home_list.html',
                  {'texts': texts, 'eat_list': eat_list,
                   'date_list': date_list,
                   'activity_list': activity_list,
                   'see_list': see_list,
                   })



